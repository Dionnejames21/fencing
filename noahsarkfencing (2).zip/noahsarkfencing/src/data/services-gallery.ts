export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  images: {
    url: string;
    alt: string;
  }[];
}

export const SERVICES_GALLERY: ServiceCategory[] = [
  {
    id: "wood-fence",
    name: "Wood Fence",
    description:
      "Classic cedar and pine privacy fences, custom gates, and dog-ear fencing crafted for natural warmth, privacy, and long-term durability.",
    images: [
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/1c345a83-fd94-468d-8835-c263ea51d43b.jpg",
        alt: "Wood Fence - Cedar privacy fence with gate",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/32d5ae4e-dffd-4a3f-994e-36b6edc8c854.jpg",
        alt: "Wood Fence - Clean perimeter cedar fencing",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/289420b4-a3bf-4da1-b89b-86b07bb0fd43.jpg",
        alt: "Wood Fence - Heavy-duty wooden yard gate",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/f2e04d77-0c47-4423-9371-a83233190c7b.jpg",
        alt: "Wood Fence - Full height residential wood fence",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/e36d4cc7-bc31-42f5-bad9-17ca23076e23.jpg",
        alt: "Wood Fence - Arched gate and side fence",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/1831cdc0-9075-4f2f-bcec-8e194116e959.jpg",
        alt: "Wood Fence - Back property line wood installation",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/03091eff-5566-4883-907f-a7c3ca0eeb59.jpg",
        alt: "Wood Fence - Backyard perimeter fence",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/f4e3acb0-54aa-42b0-9649-57dce6aefc00.jpg",
        alt: "Wood Fence - Side yard boundary fencing",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/54eec8ef-b28c-4eb3-878d-ecc67ee885e9.jpg",
        alt: "Wood Fence - Corner lot privacy fencing",
      },
      {
        url: "https://vibe.filesafe.space/1792895120796113413/assets/930fcb44-11c7-413c-b752-a8eb84cac1f4.jpg",
        alt: "Wood Fence - Finished cedar privacy run",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-0767.jpg",
        alt: "Wood Fence - Residential cedar fence section",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-0770.jpg",
        alt: "Wood Fence - Dog-ear privacy fence with gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-0771.jpg",
        alt: "Wood Fence - Full property yard enclosure",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-0772.jpg",
        alt: "Wood Fence - Above-ground pool perimeter fence",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-0774.jpg",
        alt: "Wood Fence - Green space backyard cedar fence",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-1655.jpg",
        alt: "Wood Fence - Double gate residential entry",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wood/IMG-2050.jpg",
        alt: "Wood Fence - Top cap trim privacy fence line",
      },
    ],
  },
  {
    id: "chain-link",
    name: "Chain Link",
    description:
      "Galvanized and vinyl-coated chain link systems built for reliable boundary delineation, pet enclosures, and security.",
    images: [
      {
        url: "https://www.noahsarkfencing.com/images/Chainlink/chainlink.jpg",
        alt: "Chain Link - Residential side yard chain link fence with gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Chainlink/IMG-0721.jpg",
        alt: "Chain Link - Narrow side walk access gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Chainlink/IMG-0723.jpg",
        alt: "Chain Link - Backyard perimeter fence with trees",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Chainlink/IMG-0724.jpg",
        alt: "Chain Link - Extended property line heavy gauge chain link",
      },
    ],
  },
  {
    id: "wrought-iron",
    name: "Wrought Iron",
    description:
      "Ornamental iron gates, courtyard panels, and decorative security fences with powder-coated rust resistance and timeless aesthetics.",
    images: [
      {
        url: "https://www.noahsarkfencing.com/images/Wrought%20iron/IMG-1491.jpg",
        alt: "Wrought Iron - Custom decorative courtyard gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wrought%20iron/IMG-1493.jpg",
        alt: "Wrought Iron - Breezeway security gate with ornate scrollwork",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wrought%20iron/IMG-1497.jpg",
        alt: "Wrought Iron - Elegant arched iron entry gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wrought%20iron/IMG-1499.jpg",
        alt: "Wrought Iron - Residential side gate enclosure",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Wrought%20iron/IMG-1503.jpg",
        alt: "Wrought Iron - High-durability iron boundary fencing",
      },
    ],
  },
  {
    id: "glass",
    name: "Glass",
    description:
      "Ultra-sleek tempered glass panel enclosures designed for luxury pool safety, scenic balcony views, and seamless outdoor living.",
    images: [
      {
        url: "https://www.noahsarkfencing.com/images/Glass/IMG-0396.jpg",
        alt: "Glass - Luxury waterfront deck glass railing",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Glass/IMG-0397.jpg",
        alt: "Glass - Poolside tempered glass panel barrier",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Glass/IMG-0399.jpg",
        alt: "Glass - Patio walkway glass enclosure overlooking water",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Glass/IMG-0400.jpg",
        alt: "Glass - Elevated terrace glass railing installation",
      },
    ],
  },
  {
    id: "vinyl",
    name: "Vinyl",
    description:
      "Zero-maintenance, UV-stabilized vinyl privacy fences that never require painting, staining, or weather treatment.",
    images: [
      {
        url: "https://www.noahsarkfencing.com/images/Vinyl/IMG-0919.jpg",
        alt: "Vinyl - Two-tone vinyl privacy fence panel with gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Vinyl/IMG-0920.jpg",
        alt: "Vinyl - Modern tan and white vinyl side gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Vinyl/IMG-0921.jpg",
        alt: "Vinyl - Durable vinyl privacy run along patio",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Vinyl/IMG-0923.jpg",
        alt: "Vinyl - Clean residential vinyl enclosure",
      },
    ],
  },
  {
    id: "custom-vinyl",
    name: "Custom Vinyl",
    description:
      "Bespoke ranch rails, cross-buck gates, and customized multi-rail vinyl installations tailored to large properties and driveways.",
    images: [
      {
        url: "https://www.noahsarkfencing.com/images/Custom%20Vinyl/CV01.JPG",
        alt: "Custom Vinyl - White ranch rail access gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Custom%20Vinyl/CV02.JPG",
        alt: "Custom Vinyl - Front yard low-rail vinyl fencing",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Custom%20Vinyl/CV03.JPG",
        alt: "Custom Vinyl - Wide driveway single swing custom vinyl gate",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Custom%20Vinyl/CV04.JPG",
        alt: "Custom Vinyl - Front property boundary vinyl rail system",
      },
      {
        url: "https://www.noahsarkfencing.com/images/Custom%20Vinyl/CV05.JPG",
        alt: "Custom Vinyl - Street frontage multi-rail custom vinyl fence",
      },
    ],
  },
];
