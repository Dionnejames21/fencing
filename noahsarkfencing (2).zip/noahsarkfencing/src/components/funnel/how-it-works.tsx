import { useRef, type ReactNode } from "react";
import { motion, useMotionValue, useSpring, useTransform, useScroll } from "framer-motion";
import { Ruler, Trees, CalendarCheck, Hammer, Fence, Square, ArrowRight } from "lucide-react";

interface HowItWorksProps {
  onGetQuoteClick: () => void;
}

const STEPS = [
  {
    num: "1",
    title: "Submit Your Details",
    desc: "Answer a few quick questions about your property and project goals.",
    icon: Ruler,
  },
  {
    num: "2",
    title: "We Review Your Property",
    desc: "We assess your yard and scope the right fence for your space and budget.",
    icon: Trees,
  },
  {
    num: "3",
    title: "Get Your Custom Quote",
    desc: "Receive a clear, honest quote and timeline to get your fence built right.",
    icon: CalendarCheck,
  },
];

const FLOATING_TOOLS = [
  { icon: Hammer, top: "12%", left: "8%", delay: "0s" },
  { icon: Fence, top: "68%", left: "14%", delay: "1.2s" },
  { icon: Ruler, top: "22%", left: "82%", delay: "0.6s" },
  { icon: Square, top: "72%", left: "86%", delay: "1.8s" },
  { icon: Trees, top: "44%", left: "5%", delay: "2.2s" },
];

function TiltCard({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rotateX = useSpring(useTransform(my, [0, 1], [8, -8]), {
    stiffness: 200,
    damping: 18,
  });
  const rotateY = useSpring(useTransform(mx, [0, 1], [-8, 8]), {
    stiffness: 200,
    damping: 18,
  });

  return (
    <motion.div
      ref={ref}
      onMouseMove={(e) => {
        const el = ref.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        mx.set((e.clientX - rect.left) / rect.width);
        my.set((e.clientY - rect.top) / rect.height);
      }}
      onMouseLeave={() => {
        mx.set(0.5);
        my.set(0.5);
      }}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className="tilt-card frost-card rounded-2xl p-4 sm:p-5 shadow-lg shadow-black/30 h-full"
    >
      {children}
    </motion.div>
  );
}

export function HowItWorks({ onGetQuoteClick }: HowItWorksProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start 75%", "end 60%"],
  });
  const lineScale = useSpring(scrollYProgress, {
    stiffness: 90,
    damping: 24,
    restDelta: 0.001,
  });

  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden py-8 sm:py-10 px-4 sm:px-6 lg:px-8 border-y border-white/10"
    >
      {/* Animated gradient wash */}
      <div className="absolute inset-0 gradient-anim opacity-70" />

      {/* Floating tool icons */}
      <div className="pointer-events-none absolute inset-0 hidden sm:block">
        {FLOATING_TOOLS.map((t, i) => (
          <div
            key={i}
            className="tool-float absolute text-primary/25"
            style={{ top: t.top, left: t.left, animationDelay: t.delay }}
          >
            <t.icon className="h-10 w-10" />
          </div>
        ))}
      </div>

      <div className="relative mx-auto max-w-4xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.45 }}
          className="mb-6"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
            Simple Process
          </span>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
            Get Your Fence In 3 Simple Steps
          </h2>
        </motion.div>

        {/* Desktop: horizontal connecting line that draws on scroll */}
        <div className="relative hidden sm:block">
          <div className="absolute left-[16%] right-[16%] top-[58px] h-0.5 bg-white/10" />
          <motion.div
            style={{ scaleX: lineScale }}
            className="absolute left-[16%] right-[16%] top-[58px] h-0.5 origin-left"
            // gradient line
          >
            <div
              className="h-full w-full"
              style={{
                background: "linear-gradient(90deg, var(--primary), var(--accent))",
              }}
            />
          </motion.div>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 text-left">
          {STEPS.map((step, i) => (
            <motion.div
              key={step.num}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.45, delay: i * 0.12 }}
            >
              <TiltCard>
                <div style={{ transform: "translateZ(40px)" }}>
                  <span className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-sm shadow-md shadow-primary/40 ring-1 ring-primary/30">
                    {step.num}
                  </span>
                  <h3 className="font-bold text-sm sm:text-base text-foreground">{step.title}</h3>
                  <p className="mt-1.5 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>

        <button
          type="button"
          onClick={onGetQuoteClick}
          className="cta-glow mt-7 inline-flex items-center gap-2 rounded-2xl bg-accent px-6 py-3 text-sm font-bold text-accent-foreground shadow-xl shadow-accent/30 cursor-pointer"
        >
          Get My Free Estimate
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  );
}
