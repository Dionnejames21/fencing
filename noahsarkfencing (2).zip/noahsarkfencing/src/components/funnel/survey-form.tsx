import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, ArrowRight, Loader2, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { postTrackingEvent, getTrackingSessionId } from "@/lib/tracking";

// Registered Custom Field IDs:
// Looking For Fencing Services: 9sg86fKB86btGhxs4VRn
// Is Homeowner / Decision Maker: UaJX7jvV2yrTuJtHwnVv
// Home Area: aMGR7Lw5BSBTBzQoARkq
// Schedule Within 30 Days: l936Qnlf8rQilwQLpTTp

const FIELD_TARGET_AUDIENCE = "9sg86fKB86btGhxs4VRn";
const FIELD_IS_HOMEOWNER = "UaJX7jvV2yrTuJtHwnVv";
const FIELD_SCHEDULE_30 = "l936Qnlf8rQilwQLpTTp";

interface SurveyFormProps {
  onSuccess?: () => void;
}

export function SurveyForm({ onSuccess }: SurveyFormProps) {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);

  // Form State
  const [lookingFencing, setLookingFencing] = useState<string | null>(null);
  const [isHomeowner, setIsHomeowner] = useState<string | null>(null);
  const [schedule30, setSchedule30] = useState<string | null>(null);

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const totalSteps = 4;

  const yesNoOptions = [
    { label: "Yes", value: "Yes" },
    { label: "No", value: "No" },
  ];

  function canNext() {
    if (step === 0) return lookingFencing !== null;
    if (step === 1) return isHomeowner !== null;
    if (step === 2) return schedule30 !== null;
    if (step === 3) {
      return (
        fullName.trim().length >= 2 &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) &&
        phone.replace(/\D/g, "").length >= 10
      );
    }
    return false;
  }

  function handleNext() {
    if (!canNext()) {
      setErrorMsg("Please make a selection to continue.");
      return;
    }
    setErrorMsg("");
    if (step < totalSteps - 1) {
      setStep((s) => s + 1);
    } else {
      void handleSubmit();
    }
  }

  async function handleSubmit() {
    setSubmitting(true);
    setErrorMsg("");

    try {
      // Save contact info locally so /booking page can pre-fill
      try {
        localStorage.setItem("noahs_ark_contact_data", JSON.stringify({ fullName, email, phone }));
      } catch {
        // Safe localStorage write fallback
      }

      const trackingPayload = {
        type: "external_form_submission",
        timestamp: Date.now(),
        formId: "fencing-prequalify-survey",
        formData: {
          first_name: fullName.split(" ")[0] || fullName,
          last_name: fullName.split(" ").slice(1).join(" ") || "",
          email: email.trim(),
          phone: phone.trim(),
        },
        formLabels: {
          first_name: "First Name",
          last_name: "Last Name",
          email: "Email Address",
          phone: "Phone Number",
        },
        url: window.location.href,
        title: document.title,
        path: window.location.pathname,
        userAgent: navigator.userAgent,
        trackingId: "tk_931d0da78a4540708266a1b99546fb7a",
        locationId: "UdTprqHH1xEFL8vqM5Zd",
        projectId: "1792895120796113413",
        sessionId: getTrackingSessionId(),
        properties: {
          deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
          source: "ai_studio",
          projectId: "1792895120796113413",
          formName: "Fencing Prequalify Survey",
        },
      };

      const customFields: Record<string, { value: string; label: string }> = {};
      if (lookingFencing) {
        customFields[FIELD_TARGET_AUDIENCE] = {
          value: lookingFencing,
          label: "Looking For Fencing Services",
        };
      }
      if (isHomeowner) {
        customFields[FIELD_IS_HOMEOWNER] = {
          value: isHomeowner,
          label: "Is Homeowner / Decision Maker",
        };
      }
      if (schedule30) {
        customFields[FIELD_SCHEDULE_30] = {
          value: schedule30,
          label: "Schedule Within 30 Days",
        };
      }

      postTrackingEvent(trackingPayload, { customFields });

      if (onSuccess) {
        onSuccess();
      }

      // Redirect immediately to /booking funnel step
      void navigate({ to: "/booking" as any });
    } catch {
      // Proceed even on network hiccup
      void navigate({ to: "/booking" as any });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="w-full max-w-xl mx-auto rounded-2xl border border-white/10 bg-background/50 backdrop-blur-xl p-4 sm:p-5 shadow-2xl shadow-black/30">
      {/* Progress Bar */}
      <div className="mb-3.5">
        <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          <span>
            Question {step + 1} of {totalSteps}
          </span>
          <span>{Math.round(((step + 1) / totalSteps) * 100)}% Complete</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full bg-accent transition-all duration-300"
            style={{ width: `${((step + 1) / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      {errorMsg && (
        <div className="mb-3 rounded-xl bg-destructive/10 p-3 text-xs font-semibold text-destructive">
          {errorMsg}
        </div>
      )}

      {/* Step 0: Looking for fencing services */}
      {step === 0 && (
        <motion.div
          key="step-0"
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="space-y-3"
        >
          <h2 className="text-base sm:text-lg font-bold text-foreground">
            1. Are you looking for professional fencing services?
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground">
            We build premium fences for homeowners who want it done right the first time.
          </p>
          <div className="grid gap-2 pt-1">
            {yesNoOptions.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  setLookingFencing(opt.value);
                  setErrorMsg("");
                }}
                className={`flex items-center justify-between rounded-xl border p-3.5 text-left text-sm font-semibold transition-all ${
                  lookingFencing === opt.value
                    ? "border-accent bg-accent/10 text-accent ring-1 ring-accent"
                    : "border-white/10 bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                <span>{opt.label}</span>
                {lookingFencing === opt.value && <Check className="h-4 w-4 text-accent" />}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Step 1: Homeowner / decision maker */}
      {step === 1 && (
        <motion.div
          key="step-1"
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="space-y-3"
        >
          <h2 className="text-base sm:text-lg font-bold text-foreground">
            2. Are you the homeowner or decision maker?
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground">
            We work directly with the person who owns or decides on the property.
          </p>
          <div className="grid gap-2 pt-1">
            {yesNoOptions.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  setIsHomeowner(opt.value);
                  setErrorMsg("");
                }}
                className={`flex items-center justify-between rounded-xl border p-3.5 text-left text-sm font-semibold transition-all ${
                  isHomeowner === opt.value
                    ? "border-accent bg-accent/10 text-accent ring-1 ring-accent"
                    : "border-white/10 bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                <span>{opt.label}</span>
                {isHomeowner === opt.value && <Check className="h-4 w-4 text-accent" />}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Step 2: Schedule within 30 days */}
      {step === 2 && (
        <motion.div
          key="step-2"
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="space-y-3"
        >
          <h2 className="text-base sm:text-lg font-bold text-foreground">
            3. Are you planning to schedule your fencing service within the next 30 days?
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground">
            We prioritize homeowners who are ready to move forward soon.
          </p>
          <div className="grid gap-2 pt-1">
            {yesNoOptions.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  setSchedule30(opt.value);
                  setErrorMsg("");
                }}
                className={`flex items-center justify-between rounded-xl border p-3.5 text-left text-sm font-semibold transition-all ${
                  schedule30 === opt.value
                    ? "border-accent bg-accent/10 text-accent ring-1 ring-accent"
                    : "border-white/10 bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                <span>{opt.label}</span>
                {schedule30 === opt.value && <Check className="h-4 w-4 text-accent" />}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Step 3: Contact Details */}
      {step === 3 && (
        <motion.div
          key="step-3"
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="space-y-3"
        >
          <h2 className="text-base sm:text-lg font-bold text-foreground">
            4. Where should we send your free estimate?
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground">
            Your details stay private. Zero spam, just a clear quote and a fast reply.
          </p>

          <div className="space-y-2.5 pt-1">
            <div>
              <Label className="text-xs font-semibold text-foreground">Full Name</Label>
              <Input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="John Smith"
                className="mt-1 h-11 rounded-xl text-sm"
              />
            </div>
            <div>
              <Label className="text-xs font-semibold text-foreground">Email Address</Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john@email.com"
                className="mt-1 h-11 rounded-xl text-sm"
              />
            </div>
            <div>
              <Label className="text-xs font-semibold text-foreground">Phone Number</Label>
              <Input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(555) 000-0000"
                className="mt-1 h-11 rounded-xl text-sm"
              />
            </div>
          </div>
        </motion.div>
      )}

      {/* Action Footer */}
      <div className="mt-5 flex items-center justify-between gap-3 pt-3">
        {step > 0 ? (
          <Button
            type="button"
            variant="ghost"
            onClick={() => setStep((s) => s - 1)}
            disabled={submitting}
            className="text-xs text-muted-foreground hover:text-foreground"
          >
            Back
          </Button>
        ) : (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Shield className="h-3.5 w-3.5 text-primary" />
            <span>Free, No-Obligation Quote</span>
          </div>
        )}

        <Button
          type="button"
          onClick={handleNext}
          disabled={!canNext() || submitting}
          className="h-11 px-6 rounded-xl font-bold bg-accent text-accent-foreground shadow-md shadow-accent/30 hover:bg-accent/90 transition-all disabled:opacity-50"
        >
          {submitting ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Processing...
            </span>
          ) : step === totalSteps - 1 ? (
            <span className="flex items-center gap-1.5">
              Get My Free Estimate
              <ArrowRight className="h-4 w-4" />
            </span>
          ) : (
            <span className="flex items-center gap-1.5">
              Continue
              <ArrowRight className="h-4 w-4" />
            </span>
          )}
        </Button>
      </div>
    </div>
  );
}
