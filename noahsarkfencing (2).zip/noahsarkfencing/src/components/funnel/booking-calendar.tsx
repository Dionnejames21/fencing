import { useState, useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, Calendar, Clock, ChevronRight, ShieldCheck, User, Mail, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { postTrackingEvent, getTrackingSessionId } from "@/lib/tracking";

// Registered Custom Field IDs:
// Is Target Audience: 9sg86fKB86btGhxs4VRn
// Monthly Revenue: OGeOcXYEp7Mppq6pc7AI
// Primary Pain Point: FdrRit2nXkzTkf4bB6FM
// Growth Goal: XU7zbdG2S7hGnbBZH7c7
// Is Decision Maker: UaJX7jvV2yrTuJtHwnVv
// Home Location: aMGR7Lw5BSBTBzQoARkq
// Schedule Within 30 Days: l936Qnlf8rQilwQLpTTp

interface BookingCalendarProps {
  onSuccessRedirect?: string;
}

const AVAILABLE_DAYS = [
  { day: "Today", date: "Oct 25" },
  { day: "Tomorrow", date: "Oct 26" },
  { day: "Mon", date: "Oct 28" },
  { day: "Tue", date: "Oct 29" },
  { day: "Wed", date: "Oct 30" },
] as const;

const TIME_SLOTS = ["9:00 AM", "10:30 AM", "1:00 PM", "2:30 PM", "4:00 PM"];

export function BookingCalendar({ onSuccessRedirect = "/thank-you" }: BookingCalendarProps) {
  const navigate = useNavigate();
  const [selectedDay, setSelectedDay] = useState<string>("Oct 25");
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [redirectFailed, setRedirectFailed] = useState(false);

  // Pre-fill contact details from previous step stored in localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem("noahs_ark_contact_data");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.fullName) setFullName(parsed.fullName);
        if (parsed.email) setEmail(parsed.email);
        if (parsed.phone) setPhone(parsed.phone);
      }
    } catch {
      // safe fallback
    }
  }, []);

  async function handleBooking(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedTime || !fullName || !email) return;

    setIsSubmitting(true);

    try {
      const trackingPayload = {
        type: "external_form_submission",
        timestamp: Date.now(),
        formId: "fencing-estimate-booking",
        formData: {
          first_name: fullName.split(" ")[0] || fullName,
          last_name: fullName.split(" ").slice(1).join(" ") || "",
          email: email.trim(),
          phone: phone.trim(),
          calendar_notes: `Booked Fence Estimate for ${selectedDay} at ${selectedTime}`,
        },
        formLabels: {
          first_name: "First Name",
          last_name: "Last Name",
          email: "Email",
          phone: "Phone Number",
          calendar_notes: "Estimate Time",
        },
        url: window.location.href,
        title: document.title,
        path: window.location.pathname,
        userAgent: navigator.userAgent,
        trackingId: "tk_931d0da78a4540708266a1b99546fb7a",
        locationId: "UdTprqHH1xEFL8vqM5Zd",
        projectId: "1792895120796113413",
        sessionId: getTrackingSessionId(),
        properties: {
          deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
          source: "ai_studio",
          projectId: "1792895120796113413",
          formName: "Fence Estimate Booking",
        },
      };

      postTrackingEvent(trackingPayload);

      // Simulate short API network latency
      await new Promise((r) => setTimeout(r, 600));

      setIsConfirmed(true);

      // Perform guaranteed relative path redirect to /thank-you
      try {
        await navigate({ to: onSuccessRedirect as any });
      } catch {
        setRedirectFailed(true);
      }
    } catch {
      setRedirectFailed(true);
      setIsConfirmed(true);
    } finally {
      setIsSubmitting(false);
    }
  }

  if (isConfirmed && redirectFailed) {
    return (
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/10 text-accent">
          <Check className="h-6 w-6" />
        </div>
        <h3 className="font-display text-xl font-bold text-foreground">Estimate Confirmed</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Your booking is confirmed. Please check your email for details.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6 text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          <Calendar className="h-3.5 w-3.5" />
          Select Date &amp; Time
        </span>
        <h2 className="mt-2 text-lg font-bold text-foreground">Free Fence Estimate (30 Min)</h2>
      </div>

      <form onSubmit={handleBooking} className="space-y-6">
        {/* Date Selection */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            1. Select Day
          </Label>
          <div className="mt-2 grid grid-cols-5 gap-2">
            {AVAILABLE_DAYS.map((d) => (
              <button
                key={d.date}
                type="button"
                onClick={() => setSelectedDay(d.date)}
                className={`flex flex-col items-center justify-center rounded-xl border p-2 text-center transition-all ${
                  selectedDay === d.date
                    ? "border-accent bg-accent text-accent-foreground font-semibold shadow-sm shadow-accent/30"
                    : "border-white/10 bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                <span className="text-xs opacity-80">{d.day}</span>
                <span className="text-sm font-bold">{d.date}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Time Selection */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut", delay: 0.05 }}
        >
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            2. Select Time Slot
          </Label>
          <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
            {TIME_SLOTS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setSelectedTime(t)}
                className={`flex items-center justify-center gap-1.5 rounded-xl border py-2.5 px-3 text-sm transition-all ${
                  selectedTime === t
                    ? "border-accent bg-accent text-accent-foreground font-semibold shadow-sm shadow-accent/30"
                    : "border-white/10 bg-white/5 hover:bg-white/10 text-foreground"
                }`}
              >
                <Clock className="h-3.5 w-3.5 opacity-70" />
                {t}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Contact info pre-filled */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut", delay: 0.1 }}
          className="space-y-3 border-t border-border pt-4"
        >
          <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            3. Confirm Your Information
          </Label>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label className="text-xs text-muted-foreground">Full Name</Label>
              <div className="relative mt-1">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="John Doe"
                  className="pl-9 h-11 text-sm rounded-xl"
                />
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Email Address</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@email.com"
                  className="pl-9 h-11 text-sm rounded-xl"
                />
              </div>
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs text-muted-foreground">Phone Number</Label>
              <div className="relative mt-1">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(555) 000-0000"
                  className="pl-9 h-11 text-sm rounded-xl"
                />
              </div>
            </div>
          </div>
        </motion.div>

        <Button
          type="submit"
          disabled={!selectedTime || isSubmitting}
          className="w-full h-12 rounded-xl text-base font-bold bg-accent text-accent-foreground shadow-md hover:bg-accent/90 transition-all disabled:opacity-50"
        >
          {isSubmitting ? (
            "Confirming Your Estimate..."
          ) : (
            <span className="flex items-center justify-center gap-2">
              Confirm My Fence Estimate
              <ChevronRight className="h-4 w-4" />
            </span>
          )}
        </Button>

        <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground text-center">
          <ShieldCheck className="h-4 w-4 text-primary" />
          100% Free · No obligation · Instant confirmation
        </p>
      </form>
    </div>
  );
}
