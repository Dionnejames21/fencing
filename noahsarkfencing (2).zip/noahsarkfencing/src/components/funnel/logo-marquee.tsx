import { Hammer, Ruler, Trees, Fence, Square, PanelsTopLeft } from "lucide-react";

/**
 * Scrolling marquee of materials & craftsmanship signals.
 * Uses material / service descriptors (not fabricated brand partnerships)
 * so nothing here implies an endorsement we cannot verify.
 */
const ITEMS = [
  { label: "Cedar Wood", icon: Trees },
  { label: "Vinyl Privacy", icon: PanelsTopLeft },
  { label: "Chain Link", icon: Fence },
  { label: "Wrought Iron", icon: Hammer },
  { label: "Tempered Glass", icon: Square },
  { label: "Custom Vinyl", icon: Ruler },
  { label: "Driveway Gates", icon: Hammer },
  { label: "Pool Enclosures", icon: Fence },
];

export function LogoMarquee() {
  const row = [...ITEMS, ...ITEMS];

  return (
    <section className="relative py-5 sm:py-6 border-y border-white/10 frost-soft">
      <p className="mb-3 text-center text-[11px] font-semibold uppercase tracking-[0.3em] text-white/55">
        Materials &amp; craftsmanship we build with
      </p>
      <div className="marquee-mask overflow-hidden">
        <div className="marquee-track flex w-max items-center gap-8 sm:gap-12">
          {row.map((item, i) => (
            <div
              key={`${item.label}-${i}`}
              className="flex shrink-0 items-center gap-2 text-white/75"
            >
              <item.icon className="h-5 w-5 text-primary" />
              <span className="font-display text-base sm:text-lg font-semibold tracking-tight">
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
