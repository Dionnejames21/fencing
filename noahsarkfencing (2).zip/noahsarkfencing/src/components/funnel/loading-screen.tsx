import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const LOGO_URL = "https://www.noahsarkfencing.com/images/IMG-0764.jpg";

/**
 * Branded loading screen — shows the logo + an animated progress bar and
 * fades out once the window has fully loaded (with a safe fallback timer).
 */
export function LoadingScreen() {
  const [done, setDone] = useState(false);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const finish = () => {
      timer = setTimeout(() => setDone(true), 350);
    };

    if (document.readyState === "complete") {
      finish();
    } else {
      window.addEventListener("load", finish);
    }
    const fallback = setTimeout(finish, 2400);

    return () => {
      window.removeEventListener("load", finish);
      clearTimeout(timer);
      clearTimeout(fallback);
    };
  }, []);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="loading-screen"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
        >
          <div className="flex flex-col items-center gap-5 px-6">
            <motion.img
              src={LOGO_URL}
              alt="Noah's Ark Fencing"
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="h-20 w-auto rounded-2xl border border-white/15 bg-background/70 p-2 object-contain shadow-xl"
            />
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.15 }}
              className="h-1 w-44 overflow-hidden rounded-full bg-white/10"
            >
              <motion.div
                className="h-full rounded-full"
                style={{
                  background: "linear-gradient(90deg, var(--primary), var(--accent))",
                }}
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 1.4, ease: "easeInOut" }}
              />
            </motion.div>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-[11px] font-semibold uppercase tracking-[0.35em] text-white/60"
            >
              Noah&apos;s Ark Fencing
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
