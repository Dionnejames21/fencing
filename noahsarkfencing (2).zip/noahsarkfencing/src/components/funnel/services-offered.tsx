import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Eye, X, ChevronLeft, ChevronRight } from "lucide-react";
import { SERVICES_GALLERY, type ServiceCategory } from "@/data/services-gallery";

interface ServicesOfferedProps {
  onGetQuoteClick?: () => void;
}

export function ServicesOffered({ onGetQuoteClick }: ServicesOfferedProps) {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [lightbox, setLightbox] = useState<{
    categoryIndex: number;
    imageIndex: number;
  } | null>(null);

  const displayedCategories: ServiceCategory[] =
    activeCategory === "all"
      ? SERVICES_GALLERY
      : SERVICES_GALLERY.filter((cat) => cat.id === activeCategory);

  function openLightbox(categoryIndex: number, imageIndex: number) {
    setLightbox({ categoryIndex, imageIndex });
  }

  function closeLightbox() {
    setLightbox(null);
  }

  function nextImage() {
    if (!lightbox) return;
    const cat = SERVICES_GALLERY[lightbox.categoryIndex];
    if (!cat) return;
    const nextIdx = (lightbox.imageIndex + 1) % cat.images.length;
    setLightbox({ ...lightbox, imageIndex: nextIdx });
  }

  function prevImage() {
    if (!lightbox) return;
    const cat = SERVICES_GALLERY[lightbox.categoryIndex];
    if (!cat) return;
    const prevIdx = (lightbox.imageIndex - 1 + cat.images.length) % cat.images.length;
    setLightbox({ ...lightbox, imageIndex: prevIdx });
  }

  const currentLightboxImage =
    lightbox !== null
      ? SERVICES_GALLERY[lightbox.categoryIndex]?.images[lightbox.imageIndex]
      : null;

  return (
    <section
      id="services-offered"
      className="py-8 sm:py-12 px-4 sm:px-6 lg:px-8 border-t border-white/10 frost-soft"
    >
      <div className="mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
            Real Work From Our Projects
          </span>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-foreground">
            Our Services Offered
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-muted-foreground max-w-xl mx-auto">
            Browse our complete gallery of completed installations in Devine, Texas. Every photo
            below is real work from Noah&apos;s Ark Fencing.
          </p>

          {/* Quick Filter Pills */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => setActiveCategory("all")}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                activeCategory === "all"
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/30"
                  : "bg-card border border-white/10 text-muted-foreground hover:text-foreground hover:border-primary/40"
              }`}
            >
              All Categories ({SERVICES_GALLERY.reduce((acc, c) => acc + c.images.length, 0)})
            </button>
            {SERVICES_GALLERY.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/30"
                    : "bg-card border border-white/10 text-muted-foreground hover:text-foreground hover:border-primary/40"
                }`}
              >
                {cat.name} ({cat.images.length})
              </button>
            ))}
          </div>
        </div>

        {/* Categories Stack */}
        <div className="space-y-8 sm:space-y-12">
          {displayedCategories.map((category) => {
            const globalCatIndex = SERVICES_GALLERY.findIndex((c) => c.id === category.id);

            return (
              <div
                key={category.id}
                id={category.id}
                className="frost-panel rounded-2xl p-4 sm:p-6"
              >
                {/* Category Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 mb-4 border-b border-white/10">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-display text-xl sm:text-2xl font-bold text-foreground">
                        {category.name}
                      </h3>
                      <span className="rounded-full bg-primary/15 border border-primary/30 px-2.5 py-0.5 text-[11px] font-bold text-primary">
                        {category.images.length} {category.images.length === 1 ? "Photo" : "Photos"}
                      </span>
                    </div>
                    <p className="mt-1 text-xs sm:text-sm text-muted-foreground max-w-2xl leading-relaxed">
                      {category.description}
                    </p>
                  </div>

                  {onGetQuoteClick && (
                    <button
                      type="button"
                      onClick={onGetQuoteClick}
                      className="inline-flex items-center gap-1.5 self-start sm:self-auto text-xs font-bold text-primary hover:text-accent transition-colors cursor-pointer shrink-0"
                    >
                      Get {category.name} Quote <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>

                {/* All Images in this Category */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-3 sm:gap-4">
                  {category.images.map((img, imgIdx) => (
                    <motion.div
                      key={img.url}
                      whileHover={{ scale: 1.03, y: -4 }}
                      transition={{ duration: 0.2 }}
                      onClick={() => openLightbox(globalCatIndex, imgIdx)}
                      className="group relative aspect-4/3 w-full overflow-hidden rounded-xl border border-white/10 bg-background/50 shadow-md shadow-black/20 cursor-pointer"
                    >
                      <img
                        src={img.url}
                        alt={img.alt}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-108"
                      />
                      <div className="absolute inset-0 bg-linear-to-t from-black/75 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2.5">
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-white">
                          <Eye className="h-3 w-3 text-primary" /> View larger
                        </span>
                      </div>
                      <div className="absolute top-2 right-2 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] font-bold text-white/90 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity">
                        #{imgIdx + 1}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {lightbox && currentLightboxImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeLightbox}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center"
            >
              <button
                type="button"
                onClick={closeLightbox}
                className="absolute -top-10 right-0 sm:top-2 sm:right-2 z-10 rounded-full bg-card/80 border border-white/20 p-2 text-white hover:bg-card transition-colors cursor-pointer"
                aria-label="Close image preview"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="relative w-full max-h-[75vh] flex items-center justify-center overflow-hidden rounded-2xl border border-white/15 bg-black/50">
                <img
                  src={currentLightboxImage.url}
                  alt={currentLightboxImage.alt}
                  className="max-h-[75vh] w-auto max-w-full object-contain"
                />

                {/* Prev / Next controls */}
                <button
                  type="button"
                  onClick={prevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 hover:bg-black/80 border border-white/20 p-2 text-white transition-colors cursor-pointer"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 hover:bg-black/80 border border-white/20 p-2 text-white transition-colors cursor-pointer"
                  aria-label="Next image"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>

              {/* Caption */}
              <div className="mt-3 text-center px-4">
                <p className="text-sm font-semibold text-white">
                  {SERVICES_GALLERY[lightbox.categoryIndex]?.name} — Photo {lightbox.imageIndex + 1}{" "}
                  of {SERVICES_GALLERY[lightbox.categoryIndex]?.images.length}
                </p>
                <p className="text-xs text-white/70 mt-0.5">{currentLightboxImage.alt}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
