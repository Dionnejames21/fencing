import { useEffect, useState } from "react";
import { motion, AnimatePresence, useScroll } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

interface StickyCtaProps {
  onClick: () => void;
}

/** Floating CTA that appears once the visitor scrolls past the hero. */
export function StickyCta({ onClick }: StickyCtaProps) {
  const [show, setShow] = useState(false);
  const { scrollY } = useScroll();

  useEffect(() => {
    return scrollY.on("change", (v) => {
      setShow(v > 620);
    });
  }, [scrollY]);

  return (
    <AnimatePresence>
      {show && (
        <motion.button
          type="button"
          onClick={onClick}
          initial={{ opacity: 0, y: 24, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 24, scale: 0.9 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          className="cta-glow fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3.5 text-sm font-bold text-accent-foreground shadow-2xl shadow-accent/40 cursor-pointer"
          aria-label="Get your free estimate"
        >
          Get My Free Estimate
          <ArrowUpRight className="h-4 w-4" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
