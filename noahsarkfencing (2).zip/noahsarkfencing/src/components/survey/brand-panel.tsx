import { motion } from "framer-motion";
import { Star, ShieldCheck } from "lucide-react";

const HERO_IMAGE =
  "https://vibe.filesafe.space/1792895120796113413/assets/329f0168-2863-4425-89d0-d126fc7a5354.png";

function FenceMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M4 28V10l4-3 4 3v18M16 28V10l4-3 4 3v18"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M2 16h28M2 22h28" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

const stats = [
  { value: "1,200+", label: "Fences installed" },
  { value: "4.9★", label: "Average rating" },
  { value: "25 yr", label: "Materials warranty" },
];

export function BrandPanel() {
  return (
    <aside className="relative hidden w-[44%] max-w-2xl shrink-0 overflow-hidden lg:block xl:w-[46%]">
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt="Newly installed cedar privacy fence around a landscaped suburban backyard at golden hour"
          className="h-full w-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/85 via-primary/55 to-primary/90" />
        <div className="absolute inset-0 bg-[radial-gradient(120%_80%_at_20%_0%,transparent,oklch(0.2_0.05_158)/70%)]" />
      </div>

      <div className="relative flex h-full flex-col justify-between p-10 text-primary-foreground xl:p-14">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex items-center gap-3"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-foreground/15 ring-1 ring-primary-foreground/25 backdrop-blur-sm">
            <FenceMark className="h-6 w-6 text-primary-foreground" />
          </span>
          <div className="leading-tight">
            <p className="font-display text-xl font-semibold tracking-tight">Field &amp; Form</p>
            <p className="text-xs uppercase tracking-[0.22em] text-primary-foreground/70">
              Fencing Co.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.12, ease: "easeOut" }}
          className="max-w-md"
        >
          <h2 className="font-display text-4xl font-semibold leading-[1.05] tracking-tight text-balance xl:text-5xl">
            Boundaries worth admiring.
          </h2>
          <p className="mt-5 text-pretty text-base leading-relaxed text-primary-foreground/80">
            Premium residential fencing built to last — from cedar privacy to modern
            horizontal-slat. Tell us about your project and get a no-obligation quote in minutes.
          </p>

          <div className="mt-9 grid grid-cols-3 gap-4 border-t border-primary-foreground/15 pt-7">
            {stats.map((s) => (
              <div key={s.label}>
                <p className="font-display text-2xl font-semibold">{s.value}</p>
                <p className="mt-1 text-xs leading-tight text-primary-foreground/65">{s.label}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.24, ease: "easeOut" }}
          className="flex items-center gap-3 rounded-2xl bg-primary-foreground/10 p-4 ring-1 ring-primary-foreground/15 backdrop-blur-sm"
        >
          <div className="flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-4 w-4 fill-accent text-accent" strokeWidth={0} />
            ))}
          </div>
          <p className="text-sm leading-snug text-primary-foreground/85">
            <span className="font-semibold text-primary-foreground">
              “Showed up on time, finished early, and the fence is gorgeous.”
            </span>
            <span className="block text-primary-foreground/60">— Marisol R., Devine, Texas</span>
          </p>
        </motion.div>

        <div className="flex items-center gap-2 text-xs text-primary-foreground/60">
          <ShieldCheck className="h-4 w-4" />
          Licensed · Bonded · Insured
        </div>
      </div>
    </aside>
  );
}

export { FenceMark };
