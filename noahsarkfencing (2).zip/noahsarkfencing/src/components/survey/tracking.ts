import type { SurveyAnswers } from "./types";
import { AREA_LABELS, REVENUE_LABELS } from "./types";
import { postTrackingEvent, getTrackingSessionId } from "@/lib/tracking";

const TRACKING_ID = "tk_931d0da78a4540708266a1b99546fb7a";
const LOCATION_ID = "UdTprqHH1xEFL8vqM5Zd";
const PROJECT_ID = "1792895120796113413";
const FORM_ID = "fencing-quote-survey";
const FORM_NAME = "Fencing Quote Survey";

// Custom field IDs returned by register_custom_field
const FIELD_IDS = {
  isOwner: "NFmp8qfkJYhiSw3V7YrS",
  isTargetAudience: "9sg86fKB86btGhxs4VRn",
  monthlyRevenue: "OGeOcXYEp7Mppq6pc7AI",
  wantsFencing: "OOgLwBxTxwu6KhtcUqiT",
  homeArea: "blc4oKb40cZ6HOfQQKA2",
  scheduleWithin30Days: "tvdcAxVh68eugpFb2If0",
} as const;

function yesNoLabel(v: string | null): string {
  if (v === "yes") return "Yes";
  if (v === "no") return "No";
  return "—";
}

export function trackSurveySubmission(answers: SurveyAnswers) {
  const [firstName = "", ...rest] = answers.fullName.trim().split(/\s+/);
  const lastName = rest.join(" ");

  const trackingPayload = {
    type: "external_form_submission",
    timestamp: Date.now(),
    formId: FORM_ID,
    formData: {
      first_name: firstName,
      last_name: lastName,
      email: answers.email.trim(),
      phone: answers.phone.trim(),
    },
    formLabels: {
      first_name: "First name",
      last_name: "Last name",
      email: "Email address",
      phone: "Phone number",
    },
    url: window.location.href,
    title: document.title,
    path: window.location.pathname,
    userAgent: navigator.userAgent,
    trackingId: TRACKING_ID,
    locationId: LOCATION_ID,
    projectId: PROJECT_ID,
    sessionId: getTrackingSessionId(),
    properties: {
      deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
      source: "ai_studio",
      projectId: PROJECT_ID,
      formName: FORM_NAME,
    },
  };

  postTrackingEvent(trackingPayload, {
    customFields: {
      [FIELD_IDS.isOwner]: {
        value: yesNoLabel(answers.isOwner),
        label: "Is Owner / Decision Maker",
      },
      [FIELD_IDS.isTargetAudience]: {
        value: yesNoLabel(answers.isTargetAudience),
        label: "Is Target Audience",
      },
      [FIELD_IDS.monthlyRevenue]: {
        value: REVENUE_LABELS[answers.monthlyRevenue ?? ""] ?? "—",
        label: "Monthly Revenue",
      },
      [FIELD_IDS.wantsFencing]: {
        value: yesNoLabel(answers.wantsFencing),
        label: "Wants Fencing Services",
      },
      [FIELD_IDS.homeArea]: {
        value: AREA_LABELS[answers.homeArea ?? ""] ?? "—",
        label: "Home Area",
      },
      [FIELD_IDS.scheduleWithin30Days]: {
        value: yesNoLabel(answers.scheduleWithin30Days),
        label: "Scheduling Within 30 Days",
      },
    },
  });
}

// keep imports referenced
void AREA_LABELS;
void REVENUE_LABELS;
