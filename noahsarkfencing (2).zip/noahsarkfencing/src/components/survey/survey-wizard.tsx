import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, Loader2, RotateCcw, Sparkles } from "lucide-react";
import { OptionCard } from "./option-card";
import {
  AREA_LABELS,
  EMPTY_ANSWERS,
  REVENUE_LABELS,
  REVENUE_OPTIONS,
  AREA_OPTIONS,
  YES_NO_OPTIONS,
  type SurveyAnswers,
} from "./types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface SurveyWizardProps {
  onSubmit: (answers: SurveyAnswers) => Promise<void>;
}

type StepKind = "choice" | "contact";

interface StepDef {
  kind: StepKind;
  field: keyof SurveyAnswers;
  title: string;
  subtitle: string;
}

const STEPS: StepDef[] = [
  {
    kind: "choice",
    field: "isOwner",
    title: "Are you the owner and the decision maker?",
    subtitle: "We work directly with homeowners who call the shots.",
  },
  {
    kind: "choice",
    field: "isTargetAudience",
    title: "Are you part of our target audience?",
    subtitle: "Helps us tailor the right materials and timeline for you.",
  },
  {
    kind: "choice",
    field: "monthlyRevenue",
    title: "What is your current monthly revenue?",
    subtitle: "Kept private — used only to scope the right project tier.",
  },
  {
    kind: "choice",
    field: "wantsFencing",
    title: "Are you looking for professional house fencing services?",
    subtitle: "This is what we do best.",
  },
  {
    kind: "choice",
    field: "homeArea",
    title: "Which area is your home located in?",
    subtitle: "We currently serve the Southwest and North Texas.",
  },
  {
    kind: "choice",
    field: "scheduleWithin30Days",
    title: "Are you planning to schedule your fencing service within the next 30 days?",
    subtitle: "Faster projects get priority scheduling.",
  },
  {
    kind: "contact",
    field: "fullName",
    title: "Where should we send your quote?",
    subtitle: "We'll reach out within one business day.",
  },
];

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function SurveyWizard({ onSubmit }: SurveyWizardProps) {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [answers, setAnswers] = useState<SurveyAnswers>(EMPTY_ANSWERS);
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const current = STEPS[step]!;
  const isLast = step === STEPS.length - 1;
  const total = STEPS.length;

  const choiceValue = current.kind === "choice" ? answers[current.field] : null;
  const canProceed = useMemo(() => {
    if (current.kind === "contact") {
      return (
        answers.fullName.trim().length > 1 &&
        EMAIL_RE.test(answers.email.trim()) &&
        answers.phone.replace(/\D/g, "").length >= 10
      );
    }
    return choiceValue !== null;
  }, [current, choiceValue, answers]);

  function selectChoice(value: string) {
    setAnswers((prev) => ({ ...prev, [current.field]: value }));
    setTouched(false);
  }

  function next() {
    if (!canProceed) {
      setTouched(true);
      return;
    }
    if (isLast) {
      void submit();
      return;
    }
    setDirection(1);
    setStep((s) => Math.min(s + 1, total - 1));
  }

  function back() {
    setDirection(-1);
    setTouched(false);
    setStep((s) => Math.max(s - 1, 0));
  }

  async function submit() {
    setSubmitting(true);
    try {
      await onSubmit(answers);
      setSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  }

  function restart() {
    setAnswers(EMPTY_ANSWERS);
    setStep(0);
    setTouched(false);
    setSubmitted(false);
    setDirection(1);
  }

  const progress = Math.round(((step + (submitted ? 1 : 0)) / total) * 100);

  if (submitted) {
    return <SuccessScreen answers={answers} progress={100} onRestart={restart} />;
  }

  return (
    <div className="flex w-full flex-col">
      {/* Progress */}
      <div className="mb-8">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
            Step {step + 1} of {total}
          </span>
          <span className="text-xs font-medium text-muted-foreground">{progress}% complete</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
            initial={false}
            animate={{ width: `${progress}%` }}
            transition={{ type: "spring", stiffness: 120, damping: 20 }}
          />
        </div>
      </div>

      <div className="relative flex-1">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={step}
            custom={direction}
            initial={{ opacity: 0, x: direction * 28 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -28 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          >
            <h1 className="font-display text-2xl font-semibold leading-tight tracking-tight text-foreground text-balance sm:text-3xl">
              {current.title}
            </h1>
            <p className="mt-3 text-sm text-muted-foreground sm:text-base">{current.subtitle}</p>

            <div className="mt-7">
              {current.kind === "choice" ? (
                <ChoiceStep field={current.field} value={choiceValue} onSelect={selectChoice} />
              ) : (
                <ContactStep answers={answers} setAnswers={setAnswers} touched={touched} />
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Nav */}
      <div className="mt-10 flex items-center justify-between gap-3">
        <Button
          type="button"
          variant="ghost"
          onClick={back}
          disabled={step === 0 || submitting}
          className="text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-1.5 h-4 w-4" />
          Back
        </Button>

        <Button
          type="button"
          onClick={next}
          disabled={!canProceed || submitting}
          className="min-w-[10rem] bg-primary text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:bg-primary/90 disabled:opacity-50"
          size="lg"
        >
          {submitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending…
            </>
          ) : isLast ? (
            <>
              Get my free quote
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          ) : (
            <>
              Continue
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

function ChoiceStep({
  field,
  value,
  onSelect,
}: {
  field: keyof SurveyAnswers;
  value: string | null;
  onSelect: (v: string) => void;
}) {
  let options: ReadonlyArray<{ label: string; value: string }>;
  if (field === "monthlyRevenue") options = REVENUE_OPTIONS;
  else if (field === "homeArea") options = AREA_OPTIONS;
  else options = YES_NO_OPTIONS;

  return (
    <div className="grid gap-3">
      {options.map((opt) => (
        <OptionCard
          key={opt.value}
          label={opt.label}
          selected={value === opt.value}
          onSelect={() => onSelect(opt.value)}
        />
      ))}
    </div>
  );
}

function ContactStep({
  answers,
  setAnswers,
  touched,
}: {
  answers: SurveyAnswers;
  setAnswers: React.Dispatch<React.SetStateAction<SurveyAnswers>>;
  touched: boolean;
}) {
  const phoneDigits = answers.phone.replace(/\D/g, "");
  const emailBad = touched && !EMAIL_RE.test(answers.email.trim());
  const phoneBad = touched && phoneDigits.length < 10;
  const nameBad = touched && answers.fullName.trim().length <= 1;

  return (
    <div className="grid gap-5">
      <Field label="Full name" bad={nameBad} error="Please enter your full name.">
        <Input
          value={answers.fullName}
          onChange={(e) => setAnswers((p) => ({ ...p, fullName: e.target.value }))}
          placeholder="Jordan Rivera"
          autoComplete="name"
          className="h-12 rounded-xl"
        />
      </Field>
      <Field label="Email address" bad={emailBad} error="Enter a valid email so we can reach you.">
        <Input
          type="email"
          value={answers.email}
          onChange={(e) => setAnswers((p) => ({ ...p, email: e.target.value }))}
          placeholder="you@email.com"
          autoComplete="email"
          className="h-12 rounded-xl"
        />
      </Field>
      <Field label="Phone number" bad={phoneBad} error="Enter a valid phone number.">
        <Input
          type="tel"
          value={answers.phone}
          onChange={(e) => setAnswers((p) => ({ ...p, phone: e.target.value }))}
          placeholder="(702) 555-0142"
          autoComplete="tel"
          className="h-12 rounded-xl"
        />
      </Field>
      <p className="flex items-start gap-2 rounded-xl bg-secondary/60 p-3 text-xs leading-relaxed text-muted-foreground">
        <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
        We respect your inbox — no spam, just your quote and a quick follow-up.
      </p>
    </div>
  );
}

function Field({
  label,
  bad,
  error,
  children,
}: {
  label: string;
  bad: boolean;
  error: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <Label className="text-sm font-medium text-foreground">{label}</Label>
      {children}
      {bad && <span className="text-xs text-destructive">{error}</span>}
    </div>
  );
}

function SuccessScreen({
  answers,
  progress: _progress,
  onRestart,
}: {
  answers: SurveyAnswers;
  progress: number;
  onRestart: () => void;
}) {
  const summary: Array<{ label: string; value: string }> = [
    { label: "Owner / decision maker", value: yesNo(answers.isOwner) },
    { label: "Target audience", value: yesNo(answers.isTargetAudience) },
    {
      label: "Monthly revenue",
      value: REVENUE_LABELS[answers.monthlyRevenue ?? ""] ?? "—",
    },
    { label: "Wants fencing services", value: yesNo(answers.wantsFencing) },
    { label: "Home area", value: AREA_LABELS[answers.homeArea ?? ""] ?? "—" },
    {
      label: "Scheduling within 30 days",
      value: yesNo(answers.scheduleWithin30Days),
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="flex flex-col"
    >
      <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
        <motion.span
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 260, damping: 16, delay: 0.1 }}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground"
        >
          <Check className="h-6 w-6" strokeWidth={3} />
        </motion.span>
      </div>
      <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground text-balance sm:text-4xl">
        Thank you, {answers.fullName.split(" ")[0] || "friend"}.
      </h1>
      <p className="mt-3 text-base text-muted-foreground">
        Your request is in. A Field &amp; Form specialist will email{" "}
        <span className="font-medium text-foreground">{answers.email}</span> and call you within one
        business day.
      </p>

      <div className="mt-8 overflow-hidden rounded-2xl border border-border bg-card">
        <dl className="divide-y divide-border">
          {summary.map((row) => (
            <div key={row.label} className="flex items-center justify-between gap-4 px-4 py-3">
              <dt className="text-sm text-muted-foreground">{row.label}</dt>
              <dd className="text-right text-sm font-medium text-foreground">{row.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="mt-8">
        <Button
          type="button"
          variant="outline"
          onClick={onRestart}
          className="text-muted-foreground"
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Submit another request
        </Button>
      </div>
    </motion.div>
  );
}

function yesNo(v: string | null): string {
  if (v === "yes") return "Yes";
  if (v === "no") return "No";
  return "—";
}

// keep cn import referenced for tree-shaking safety in variants
void cn;
