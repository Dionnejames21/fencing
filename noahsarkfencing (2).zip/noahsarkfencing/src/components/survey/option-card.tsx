import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface OptionCardProps {
  label: string;
  description?: string;
  selected: boolean;
  onSelect: () => void;
}

export function OptionCard({ label, description, selected, onSelect }: OptionCardProps) {
  return (
    <motion.button
      type="button"
      onClick={onSelect}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.99 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      className={cn(
        "group relative flex w-full items-center gap-4 rounded-xl border p-4 text-left transition-colors duration-200 sm:p-5",
        selected
          ? "border-primary bg-primary/[0.06] shadow-[0_0_0_2px_var(--color-ring)]"
          : "border-border bg-card hover:border-primary/50 hover:bg-secondary/50",
      )}
    >
      <span
        className={cn(
          "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-200",
          selected
            ? "border-primary bg-primary text-primary-foreground"
            : "border-muted-foreground/30 text-transparent group-hover:border-primary/60",
        )}
      >
        <Check className="h-3.5 w-3.5" strokeWidth={3} />
      </span>
      <span className="flex min-w-0 flex-col">
        <span className="font-display text-base font-medium leading-tight text-foreground sm:text-lg">
          {label}
        </span>
        {description && <span className="mt-0.5 text-sm text-muted-foreground">{description}</span>}
      </span>
    </motion.button>
  );
}
