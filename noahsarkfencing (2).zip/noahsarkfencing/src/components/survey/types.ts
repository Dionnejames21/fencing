export interface SurveyAnswers {
  isOwner: string | null;
  isTargetAudience: string | null;
  monthlyRevenue: string | null;
  wantsFencing: string | null;
  homeArea: string | null;
  scheduleWithin30Days: string | null;
  fullName: string;
  email: string;
  phone: string;
}

export const EMPTY_ANSWERS: SurveyAnswers = {
  isOwner: null,
  isTargetAudience: null,
  monthlyRevenue: null,
  wantsFencing: null,
  homeArea: null,
  scheduleWithin30Days: null,
  fullName: "",
  email: "",
  phone: "",
};

export const REVENUE_OPTIONS = [
  { label: "Less than $10,000", value: "less-than-10k" },
  { label: "$10,000 – $50,000", value: "10k-50k" },
  { label: "$50,001 – $100,000", value: "50k-100k" },
  { label: "More than $100,000", value: "more-than-100k" },
] as const;

export const AREA_OPTIONS = [{ label: "Devine, Texas", value: "devine-tx" }] as const;

export const YES_NO_OPTIONS = [
  { label: "Yes", value: "yes" },
  { label: "No", value: "no" },
] as const;

export const REVENUE_LABELS: Record<string, string> = Object.fromEntries(
  REVENUE_OPTIONS.map((o) => [o.value, o.label]),
);
export const AREA_LABELS: Record<string, string> = Object.fromEntries(
  AREA_OPTIONS.map((o) => [o.value, o.label]),
);
