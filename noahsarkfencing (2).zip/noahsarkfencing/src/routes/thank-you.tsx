import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { CheckCircle2, Mail, Phone, ArrowLeft, MapPin, Clock, ShieldCheck } from "lucide-react";
import { useParallaxBg } from "@/hooks/use-parallax-bg";

const LOGO_URL = "https://www.noahsarkfencing.com/images/IMG-0764.jpg";

export const Route = createFileRoute("/thank-you")({
  head: () => ({
    meta: [
      { title: "Thank You | Noah's Ark Fencing - Devine, Texas" },
      {
        name: "description",
        content:
          "Thank you for reaching out to Noah's Ark Fencing. Your request has been received, and our team will review your fencing project.",
      },
      {
        property: "og:title",
        content: "Thank You for Reaching Out | Noah's Ark Fencing",
      },
      {
        property: "og:description",
        content:
          "Your request has been received. We look forward to helping you find the right fencing solution for your property in Devine, Texas.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ThankYouPage,
});

function ThankYouPage() {
  const bgY = useParallaxBg();

  return (
    <motion.div
      style={{ backgroundPositionY: bgY }}
      className="min-h-screen wood-bg text-foreground flex flex-col selection:bg-primary selection:text-primary-foreground"
    >
      {/* 1. Header — Logo with generous whitespace */}
      <header className="pt-8 sm:pt-12 pb-4 px-4 text-center">
        <div className="flex justify-center">
          <Link to="/" className="inline-block transition-transform hover:scale-105">
            <img
              src={LOGO_URL}
              alt="Noah's Ark Fencing Logo"
              className="h-16 sm:h-20 w-auto rounded-2xl object-contain border border-white/15 bg-card/90 p-2 shadow-xl backdrop-blur-sm"
            />
          </Link>
        </div>
      </header>

      {/* Main Content — Welcoming, Professional, Clean Card */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-4 sm:py-6 w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="w-full max-w-2xl rounded-3xl border border-white/15 bg-card/95 backdrop-blur-xl p-6 sm:p-10 shadow-2xl shadow-black/40 text-center"
        >
          {/* Tasteful Checkmark / Success Badge */}
          <div className="flex justify-center mb-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.15 }}
              className="relative flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-full bg-primary/20 text-primary ring-2 ring-primary/40 shadow-lg shadow-primary/25"
            >
              <CheckCircle2 className="h-10 w-10 sm:h-12 sm:w-12 text-primary stroke-[2.25]" />
            </motion.div>
          </div>

          {/* Location pill */}
          <div className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1 text-xs font-semibold text-primary mb-3">
            <MapPin className="h-3.5 w-3.5" />
            <span>Devine, Texas</span>
          </div>

          {/* Headline */}
          <h1 className="font-display text-2xl sm:text-4xl font-extrabold tracking-tight text-foreground leading-tight text-balance">
            Thank You for Reaching Out!
          </h1>

          {/* Subheadline */}
          <p className="mt-2 text-base sm:text-lg font-bold text-primary tracking-normal">
            Your Request Has Been Received.
          </p>

          {/* Welcoming Message Card */}
          <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.04] p-5 sm:p-6 text-left sm:text-center space-y-3">
            <p className="text-sm sm:text-base text-foreground/90 leading-relaxed">
              Thank you for your interest in Noah&apos;s Ark Fencing! We appreciate the opportunity
              to help with your fencing project. Our team has received your information and will
              review your request.
            </p>
            <p className="text-sm sm:text-base text-foreground/90 leading-relaxed">
              We look forward to helping you find the right fencing solution for your property in{" "}
              <span className="font-bold text-foreground">Devine, Texas</span>.
            </p>

            {/* Reassurance points */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-muted-foreground border-t border-white/10">
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary shrink-0" />
                Prompt review by our local crew
              </span>
              <span className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-primary shrink-0" />
                No-pressure honest recommendations
              </span>
            </div>
          </div>

          {/* Call-to-Action Box with Clickable Contact */}
          <div className="mt-6 rounded-2xl border border-accent/40 bg-accent/10 p-5 sm:p-7 text-center">
            <h2 className="text-base sm:text-lg font-extrabold text-foreground tracking-tight">
              Have questions or need assistance? Contact us today!
            </h2>

            {/* Structured contact cards with spacious layout preventing any truncation or overflow */}
            <div className="mt-5 flex flex-col gap-3 max-w-xl mx-auto text-xs sm:text-sm">
              {/* Full-width Email card to display NoahsArkFencing@gmail.com completely */}
              <a
                href="mailto:NoahsArkFencing@gmail.com"
                className="flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl border border-white/15 bg-card/90 hover:border-primary/50 hover:bg-card text-foreground transition-all group shadow-sm"
              >
                <Mail className="h-4 w-4 shrink-0 text-primary group-hover:scale-110 transition-transform" />
                <span className="font-semibold text-muted-foreground shrink-0">Email:</span>
                <span className="font-bold text-primary break-all sm:break-normal">
                  NoahsArkFencing@gmail.com
                </span>
              </a>

              {/* Two balanced phone number cards with generous width and padding */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href="tel:+18305388189"
                  className="flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl border border-white/15 bg-card/90 hover:border-primary/50 hover:bg-card text-foreground transition-all group shadow-sm"
                >
                  <Phone className="h-4 w-4 shrink-0 text-primary group-hover:scale-110 transition-transform" />
                  <span className="font-semibold text-muted-foreground shrink-0">Office:</span>
                  <span className="font-bold text-foreground tracking-wide">(830) 538-8189</span>
                </a>

                <a
                  href="tel:+19517600040"
                  className="flex items-center justify-center gap-2.5 px-4 py-3 rounded-xl border border-white/15 bg-card/90 hover:border-primary/50 hover:bg-card text-foreground transition-all group shadow-sm"
                >
                  <Phone className="h-4 w-4 shrink-0 text-primary group-hover:scale-110 transition-transform" />
                  <span className="font-semibold text-muted-foreground shrink-0">Cell:</span>
                  <span className="font-bold text-foreground tracking-wide">(951) 760-0040</span>
                </a>
              </div>
            </div>
          </div>

          {/* Back to Home Button */}
          <div className="mt-6 flex justify-center">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Return to Homepage
            </Link>
          </div>
        </motion.div>

        {/* Tracking Pixel */}
        <script
          dangerouslySetInnerHTML={{
            __html: `if(typeof fbq==='function'){fbq('track','Schedule');}`,
          }}
        />
      </main>

      {/* 6. Footer Section — logo, business name, clickable contact, copyright */}
      <footer className="mt-auto py-6 px-4 border-t border-white/10 text-center bg-background">
        <div className="mx-auto max-w-4xl flex flex-col items-center justify-center gap-3">
          <img
            src={LOGO_URL}
            alt="Noah's Ark Fencing Logo"
            className="h-9 w-auto rounded-lg object-contain border border-white/15 bg-card p-1"
          />
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-5 text-xs sm:text-sm">
            <a
              href="mailto:NoahsArkFencing@gmail.com"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Email:</span>
              NoahsArkFencing@gmail.com
            </a>
            <a
              href="tel:+18305388189"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Office:</span>
              (830) 538-8189
            </a>
            <a
              href="tel:+19517600040"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Cell:</span>
              (951) 760-0040
            </a>
          </div>
          <p className="text-xs text-muted-foreground font-medium">
            &copy; 2026 Noah&apos;s Ark Fencing. All rights reserved.
          </p>
        </div>
      </footer>
    </motion.div>
  );
}
