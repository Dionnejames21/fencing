import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { SurveyForm } from "@/components/funnel/survey-form";
import { ServicesOffered } from "@/components/funnel/services-offered";
import { LoadingScreen } from "@/components/funnel/loading-screen";
import { ScrollProgress } from "@/components/funnel/scroll-progress";
import { StickyCta } from "@/components/funnel/sticky-cta";
import { LogoMarquee } from "@/components/funnel/logo-marquee";
import { HowItWorks } from "@/components/funnel/how-it-works";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import {
  Hammer,
  Trees,
  Clock,
  ArrowRight,
  ShieldCheck,
  Award,
  Ruler,
  CalendarCheck,
  MapPin,
  Mail,
  Phone,
} from "lucide-react";
import { useParallaxBg } from "@/hooks/use-parallax-bg";

const LOGO_URL = "https://www.noahsarkfencing.com/images/IMG-0764.jpg";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-50px" },
  transition: { duration: 0.45, ease: "easeOut" as const },
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Noah's Ark Fencing | Premium Fence Installation in Devine, Texas" },
      {
        name: "description",
        content:
          "Premium fencing for Devine, Texas homeowners. Free estimates, expert crews, and fences built to last. Get your free quote today.",
      },
      {
        property: "og:title",
        content: "Noah's Ark Fencing | Premium Fence Installation in Devine, Texas",
      },
      {
        property: "og:description",
        content:
          "Premium fencing for Devine, Texas homeowners. Free estimates, expert crews, and fences built to last.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  function scrollToSurvey() {
    const el = document.getElementById("survey-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }

  const bgY = useParallaxBg();

  return (
    <motion.div
      style={{ backgroundPositionY: bgY }}
      className="min-h-screen cinema-bg text-foreground selection:bg-primary selection:text-primary-foreground"
    >
      <LoadingScreen />
      <ScrollProgress />
      <StickyCta onClick={scrollToSurvey} />

      {/* 1. Hero Section — cinematic moody backdrop */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 hero-overlay" />
        <div className="absolute inset-0 hero-glow" />
        <div className="relative px-4 pt-5 pb-7 sm:px-6 sm:pt-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            {/* Logo at top center */}
            <div className="flex justify-center mb-3">
              <img
                src={LOGO_URL}
                alt="Noah's Ark Fencing Logo"
                className="h-14 sm:h-18 w-auto rounded-xl object-contain border border-white/15 bg-background/70 p-1.5 shadow-lg backdrop-blur-sm"
              />
            </div>

            {/* Large Bold Callout / Eyebrow Pill */}
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/15 px-5 py-2.5 text-sm sm:text-base font-extrabold text-primary shadow-lg shadow-primary/20 mb-3 backdrop-blur-sm">
              <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              <span>Attention: Devine, Texas Homeowners</span>
            </div>

            {/* Headline — the clear highlight of the page */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance leading-[1.05] text-white drop-shadow-lg">
              Get The Premium Fence You Want, Without The Contractor Runaround
            </h1>

            {/* Subheadline */}
            <p className="mt-3 text-sm sm:text-lg text-white/85 text-pretty max-w-xl mx-auto drop-shadow-sm">
              Stop chasing crews who ghost you. Get a clear, honest estimate from a crew that shows
              up on time and finishes clean.
            </p>

            {/* Primary CTA */}
            <div className="mt-4 flex flex-col items-center gap-2">
              <Button
                size="lg"
                onClick={scrollToSurvey}
                className="cta-glow h-13 px-7 text-base font-bold rounded-2xl bg-accent text-accent-foreground shadow-xl shadow-accent/30 hover:bg-accent/90 active:scale-[0.98] w-full sm:w-auto"
              >
                Get My Free Estimate
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <p className="flex items-center gap-1.5 text-xs sm:text-sm text-white/80 font-medium">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Free, No-Obligation Quote · We Respond Within 24 Hours
              </p>
            </div>

            {/* Embedded Survey Form in Hero — glass, connected */}
            <div id="survey-section" className="mt-4 scroll-mt-4">
              <SurveyForm />
            </div>
          </div>
        </div>
      </section>

      {/* Logo / materials marquee */}
      <LogoMarquee />

      {/* 2. Problem Section */}
      <motion.section
        {...fadeUp}
        className="py-7 sm:py-9 px-4 sm:px-6 lg:px-8 border-y border-white/10 frost-soft text-center"
      >
        <div className="mx-auto max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
            The Reality
          </span>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
            Tired Of Fence Contractors Who Leave You Hanging?
          </h2>
          <p className="mt-2.5 text-sm sm:text-base text-muted-foreground leading-relaxed max-w-2xl mx-auto">
            Half-finished projects. Missed calls. Estimates that climb once work starts. You deserve
            a crew that shows up, communicates, and gets it done right the first time.
          </p>
        </div>
      </motion.section>

      {/* 3. Our Services Offered Section — complete gallery with all reference pictures */}
      <ServicesOffered onGetQuoteClick={scrollToSurvey} />

      {/* 3c. Solution Highlights Section */}
      <section className="py-7 sm:py-9 px-4 sm:px-6 lg:px-8 border-t border-white/10 frost-soft">
        <div className="mx-auto max-w-5xl">
          <motion.div {...fadeUp} className="text-center max-w-3xl mx-auto mb-5">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
              The Noah&apos;s Ark Difference
            </span>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
              A Fence Done Right, Start To Finish
            </h2>
          </motion.div>

          <div className="grid gap-3.5 sm:gap-4 sm:grid-cols-3">
            {[
              {
                icon: Trees,
                title: "Premium Materials",
                desc: "Wood, vinyl, and metal built to withstand the Texas sun and local weather for years.",
              },
              {
                icon: Hammer,
                title: "Expert Installation",
                desc: "Skilled crews who measure twice and install once, clean and precise.",
              },
              {
                icon: Clock,
                title: "On-Time Delivery",
                desc: "Clear timelines and a crew that shows up when they say they will.",
              },
            ].map((card, i) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.45, ease: "easeOut", delay: i * 0.1 }}
                whileHover={{ y: -6 }}
                className="frost-card rounded-2xl p-4 sm:p-5 shadow-lg shadow-black/20 hover:border-primary/50 transition-all"
              >
                <div className="icon-bright flex h-11 w-11 items-center justify-center rounded-xl mb-3">
                  <card.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-base sm:text-lg font-bold text-foreground">
                  {card.title}
                </h3>
                <p className="mt-1.5 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  {card.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. How It Works Section — 3D tilt, animated draw line, floating tools, gradient wash */}
      <HowItWorks onGetQuoteClick={scrollToSurvey} />

      {/* 5. Why Choose Us Section */}
      <section className="py-7 sm:py-9 px-4 sm:px-6 lg:px-8 frost-soft">
        <div className="mx-auto max-w-4xl">
          <motion.div {...fadeUp} className="text-center mb-5">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
              Why Choose Us
            </span>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
              Why Homeowners Trust Noah&apos;s Ark Fencing
            </h2>
          </motion.div>

          <div className="grid gap-3 sm:gap-3.5 sm:grid-cols-2">
            {[
              {
                icon: Ruler,
                title: "Personalized Consultation",
                desc: "We walk your property and recommend the right fence for your goals and budget.",
              },
              {
                icon: Clock,
                title: "Fast Response",
                desc: "Get a quote back within 24 hours so you can move forward without the waiting game.",
              },
              {
                icon: Award,
                title: "Proven Process",
                desc: "A clear, step by step install that keeps you informed from start to finish.",
              },
              {
                icon: ShieldCheck,
                title: "No-Pressure Estimate",
                desc: "An honest, straightforward quote with zero obligation to book.",
              },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.45, ease: "easeOut", delay: i * 0.08 }}
                className="frost-card flex items-start gap-3 rounded-xl p-3.5 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/10 transition-all"
              >
                <div className="icon-bright flex h-9 w-9 shrink-0 items-center justify-center rounded-lg mt-0.5">
                  <item.icon className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-foreground">{item.title}</h4>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. FAQ Accordions Section */}
      <section className="py-7 sm:py-9 px-4 sm:px-6 lg:px-8 border-y border-white/10 frost-soft">
        <motion.div {...fadeUp} className="mx-auto max-w-3xl">
          <div className="text-center mb-5">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-3">
              Questions
            </span>
            <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
              Frequently Asked Questions
            </h2>
          </div>

          <Accordion type="single" collapsible className="w-full space-y-2.5">
            <AccordionItem
              value="faq-1"
              className="frost-card rounded-xl px-4 overflow-hidden shadow-lg shadow-black/20"
            >
              <AccordionTrigger className="text-left font-bold text-sm sm:text-base text-foreground hover:no-underline py-3.5 [&[data-state=open]_svg]:text-accent">
                What types of fencing do you install?
              </AccordionTrigger>
              <AccordionContent className="text-xs sm:text-sm text-muted-foreground pb-4 leading-relaxed">
                Wood, vinyl, chain link, and wrought iron for residential properties. Tell us your
                goal and we recommend the right material for your yard and budget.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value="faq-2"
              className="frost-card rounded-xl px-4 overflow-hidden shadow-lg shadow-black/20"
            >
              <AccordionTrigger className="text-left font-bold text-sm sm:text-base text-foreground hover:no-underline py-3.5 [&[data-state=open]_svg]:text-accent">
                How long does a fence installation take?
              </AccordionTrigger>
              <AccordionContent className="text-xs sm:text-sm text-muted-foreground pb-4 leading-relaxed">
                Most residential projects finish within one to three days once materials are on
                site, depending on the size and terrain of your property.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value="faq-3"
              className="frost-card rounded-xl px-4 overflow-hidden shadow-lg shadow-black/20"
            >
              <AccordionTrigger className="text-left font-bold text-sm sm:text-base text-foreground hover:no-underline py-3.5 [&[data-state=open]_svg]:text-accent">
                Is the estimate really free?
              </AccordionTrigger>
              <AccordionContent className="text-xs sm:text-sm text-muted-foreground pb-4 leading-relaxed">
                Yes. Your estimate is free and there is no obligation to book. We walk your property
                and give you an honest, upfront quote.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem
              value="faq-4"
              className="frost-card rounded-xl px-4 overflow-hidden shadow-lg shadow-black/20"
            >
              <AccordionTrigger className="text-left font-bold text-sm sm:text-base text-foreground hover:no-underline py-3.5 [&[data-state=open]_svg]:text-accent">
                Which areas do you serve?
              </AccordionTrigger>
              <AccordionContent className="text-xs sm:text-sm text-muted-foreground pb-4 leading-relaxed">
                We exclusively serve homeowners and property owners in Devine, Texas and surrounding
                local communities. Submit your request above to confirm your project details.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </section>

      {/* 7. Final CTA Section — cinematic moody backdrop */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 hero-overlay" />
        <div className="absolute inset-0 hero-glow" />
        <div className="relative py-9 sm:py-12 px-4 sm:px-6 lg:px-8 text-center">
          <div className="mx-auto max-w-3xl">
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold tracking-tight text-white drop-shadow-lg">
              Ready For A Fence Done Right?
            </h2>
            <p className="mt-2.5 text-sm sm:text-base text-white/85 max-w-xl mx-auto">
              Lock in your free estimate today before our installation schedule fills up.
            </p>
            <Button
              size="lg"
              onClick={scrollToSurvey}
              className="cta-glow mt-5 h-13 px-7 text-base font-bold rounded-2xl bg-accent text-accent-foreground hover:bg-accent/90 transition-all shadow-xl shadow-accent/30 w-full sm:w-auto"
            >
              Get My Free Estimate
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* 8. Footer Section */}
      <footer className="py-6 px-4 border-t border-white/10 text-center frost-soft">
        <div className="mx-auto max-w-4xl flex flex-col items-center justify-center gap-3">
          <img
            src={LOGO_URL}
            alt="Noah's Ark Fencing Logo"
            className="h-9 w-auto rounded-lg object-contain border border-white/15 bg-background/70 p-1"
          />
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-5 text-xs sm:text-sm">
            <a
              href="mailto:NoahsArkFencing@gmail.com"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Email:</span>
              NoahsArkFencing@gmail.com
            </a>
            <a
              href="tel:+18305388189"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Office:</span>
              (830) 538-8189
            </a>
            <a
              href="tel:+19517600040"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Cell:</span>
              (951) 760-0040
            </a>
          </div>
          <p className="text-xs text-muted-foreground font-medium">
            &copy; 2026 Noah&apos;s Ark Fencing. All rights reserved.
          </p>
        </div>
      </footer>
    </motion.div>
  );
}
