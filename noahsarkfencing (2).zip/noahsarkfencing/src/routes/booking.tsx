import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { CalendarCheck, ShieldCheck, Clock, Mail, Phone } from "lucide-react";
import { BookingCalendar } from "@/components/funnel/booking-calendar";
import { useParallaxBg } from "@/hooks/use-parallax-bg";

const LOGO_URL = "https://www.noahsarkfencing.com/images/IMG-0764.jpg";

export const Route = createFileRoute("/booking")({
  head: () => ({
    meta: [
      { title: "Book Your Free Fence Estimate | Noah's Ark Fencing - Devine, Texas" },
      {
        name: "description",
        content:
          "Schedule your free fence estimate with Noah's Ark Fencing in Devine, Texas. Pick a time that works for you.",
      },
      {
        property: "og:title",
        content: "Book Your Free Fence Estimate | Noah's Ark Fencing - Devine, Texas",
      },
      {
        property: "og:description",
        content: "Schedule your free fence estimate with Noah's Ark Fencing in Devine, Texas.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookingPage,
});

function BookingPage() {
  const bgY = useParallaxBg();
  return (
    <motion.div
      style={{ backgroundPositionY: bgY }}
      className="min-h-screen wood-bg text-foreground flex flex-col selection:bg-primary selection:text-primary-foreground"
    >
      {/* 1. Top Section - Logo (generous whitespace, no nav) */}
      <header className="pt-8 sm:pt-10 pb-4 px-4 text-center">
        <div className="flex justify-center">
          <img
            src={LOGO_URL}
            alt="Noah's Ark Fencing Logo"
            className="h-14 sm:h-18 w-auto rounded-xl object-contain border border-white/15 bg-card p-1.5 shadow-lg"
          />
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 px-4 pb-6 sm:px-6 max-w-2xl mx-auto w-full">
        {/* 2. Headline Section - bold, centered, visually dominant */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="text-center mb-5"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/15 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary mb-2.5">
            <CalendarCheck className="h-3.5 w-3.5" />
            Free Fence Estimate · Devine, Texas
          </span>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-balance leading-[1.1] text-foreground">
            Book Your Free Fence Estimate Now
          </h1>
          <p className="mt-2 text-sm sm:text-base text-muted-foreground max-w-md mx-auto text-pretty">
            Pick a time below to lock in your free, no-obligation property estimate in Devine,
            Texas.
          </p>
        </motion.div>

        {/* 3. Calendar Section - transparent, no bg / shadow / border */}
        <div className="mb-5">
          <BookingCalendar onSuccessRedirect="/thank-you" />
        </div>

        {/* 4. Reminder Note Section - subtle, noticeable box */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
          className="mx-auto max-w-xl rounded-2xl border border-white/10 bg-white/5 p-4 sm:p-5 text-left"
        >
          <p className="text-xs sm:text-sm font-semibold text-foreground leading-relaxed">
            <span className="flex items-center gap-1.5 text-primary font-bold uppercase tracking-wider mb-1.5">
              <Clock className="h-3.5 w-3.5" />
              Please Note
            </span>
            By booking a call, you are committing to showing up at the scheduled time. If you do not
            provide at least 24 hours notice and do not show, there is no ability to reschedule or
            rebook. We take a high volume of estimate requests and need to ensure we can help
            everyone.
          </p>
        </motion.div>

        {/* Trust line */}
        <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-muted-foreground font-medium text-center">
          <ShieldCheck className="h-4 w-4 text-primary" />
          100% Free · No obligation · Instant confirmation
        </p>

        {/* 8. Pixel Tracking */}
        <script
          dangerouslySetInnerHTML={{
            __html: `if(typeof fbq==='function'){fbq('track','Lead');}`,
          }}
        />
      </main>

      {/* 7. Footer Section */}
      <footer className="py-6 px-4 border-t border-white/10 text-center bg-background">
        <div className="mx-auto max-w-4xl flex flex-col items-center justify-center gap-3">
          <img
            src={LOGO_URL}
            alt="Noah's Ark Fencing Logo"
            className="h-9 w-auto rounded-lg object-contain border border-white/15 bg-card p-1"
          />
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-5 text-xs sm:text-sm">
            <a
              href="mailto:NoahsArkFencing@gmail.com"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Email:</span>
              NoahsArkFencing@gmail.com
            </a>
            <a
              href="tel:+18305388189"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Office:</span>
              (830) 538-8189
            </a>
            <a
              href="tel:+19517600040"
              className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            >
              <Phone className="h-3.5 w-3.5 text-primary" />
              <span className="font-semibold text-foreground">Cell:</span>
              (951) 760-0040
            </a>
          </div>
          <p className="text-xs text-muted-foreground font-medium">
            &copy; 2026 Noah&apos;s Ark Fencing. All rights reserved.
          </p>
        </div>
      </footer>
    </motion.div>
  );
}
