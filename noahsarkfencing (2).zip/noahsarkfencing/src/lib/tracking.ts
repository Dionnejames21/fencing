// Form-tracking integration helper.
// Posts the survey submission to the CRM tracking endpoint (fire-and-forget).

type StandardTrackingFieldKey = string;
type RegisteredCustomFieldId = string;
type TrackingCustomField = { value?: unknown; label: string };

type TrackingPayload = Record<string, unknown> & {
  formData: Record<StandardTrackingFieldKey, unknown>;
  formLabels: Record<StandardTrackingFieldKey, string>;
};

export function postTrackingEvent(
  trackingPayload: TrackingPayload,
  options: {
    customFields?: Record<RegisteredCustomFieldId, TrackingCustomField>;
  } = {},
) {
  const { customFields = {} } = options;
  const eventPayload = {
    ...trackingPayload,
    formData: { ...trackingPayload.formData },
    formLabels: { ...trackingPayload.formLabels },
  };
  const body = new FormData();

  for (const [key, field] of Object.entries(customFields)) {
    if (field.value === undefined) continue;
    eventPayload.formData[key] = field.value;
    eventPayload.formLabels[key] = field.label;
  }

  for (const key of Object.keys(eventPayload.formData)) {
    eventPayload.formLabels[key] ||= key;
  }

  body.append("event", JSON.stringify(eventPayload));

  fetch("https://backend.leadconnectorhq.com/external-tracking/events", {
    method: "POST",
    headers: { version: "2021-07-28" },
    body,
  }).catch(() => {});
}

export function getTrackingSessionId(): string {
  try {
    const sid = document.cookie.match(/(?:^|;\s*)__vibe_sid=([0-9a-f-]{36})(?:;|$)/)?.[1];
    if (sid) return sid;
  } catch {}
  return crypto.randomUUID();
}
