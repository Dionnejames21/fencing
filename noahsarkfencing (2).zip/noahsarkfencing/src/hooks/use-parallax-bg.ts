import { useScroll, useTransform, useSpring } from "framer-motion";

/**
 * One unified, subtle parallax for the whole page.
 *
 * The cinematic hero backdrop is `background-attachment: fixed`, so it
 * already stays planted relative to the viewport while content scrolls.
 * We additionally drift `backgroundPositionY` a hair slower than the scroll
 * so the texture breathes gently — a single, consistent motion top to bottom.
 */
export function useParallaxBg(speed = 0.18) {
  const { scrollY } = useScroll();
  const raw = useTransform(scrollY, (latest) => `${Math.round(latest * speed)}px`);
  return useSpring(raw, { stiffness: 120, damping: 30, restDelta: 0.001 });
}
